﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String UnityEngine.PhysicsScene2D::ToString()
extern void PhysicsScene2D_ToString_m6F48AC6CE0D8540FCE4914ABB78ED0BAF0D83CBE_AdjustorThunk (void);
// 0x00000002 System.Int32 UnityEngine.PhysicsScene2D::GetHashCode()
extern void PhysicsScene2D_GetHashCode_mB1C0E9E977ACCBF0AA0D266E5851B4D778354467_AdjustorThunk (void);
// 0x00000003 System.Boolean UnityEngine.PhysicsScene2D::Equals(System.Object)
extern void PhysicsScene2D_Equals_mA91E96FDE086CF876D4D469CBFF0D43400C834E8_AdjustorThunk (void);
// 0x00000004 System.Boolean UnityEngine.PhysicsScene2D::Equals(UnityEngine.PhysicsScene2D)
extern void PhysicsScene2D_Equals_mAA6F413AD3CDDD052496FAF69C34A45CA25D4293_AdjustorThunk (void);
// 0x00000005 UnityEngine.RaycastHit2D UnityEngine.PhysicsScene2D::Linecast(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.ContactFilter2D)
extern void PhysicsScene2D_Linecast_mFE9838D8AE5569DEDBF8DA9E4E7CE54524D96C9F_AdjustorThunk (void);
// 0x00000006 UnityEngine.RaycastHit2D UnityEngine.PhysicsScene2D::Linecast_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.ContactFilter2D)
extern void PhysicsScene2D_Linecast_Internal_mB1FEA3F9760D1E2AB59ABE8E17C93681E55770C2 (void);
// 0x00000007 UnityEngine.RaycastHit2D UnityEngine.PhysicsScene2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32)
extern void PhysicsScene2D_Raycast_m8A048506EDDC5C968DB55584FBF650DAB3BCB987_AdjustorThunk (void);
// 0x00000008 UnityEngine.RaycastHit2D UnityEngine.PhysicsScene2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D)
extern void PhysicsScene2D_Raycast_mFA61658E024A98E2A7BC1B6965E9E5537DCA2DB8_AdjustorThunk (void);
// 0x00000009 UnityEngine.RaycastHit2D UnityEngine.PhysicsScene2D::Raycast_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector2,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D)
extern void PhysicsScene2D_Raycast_Internal_mB24F5D2B6967C70371484EA703E16346DBFD0718 (void);
// 0x0000000A System.Int32 UnityEngine.PhysicsScene2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D,UnityEngine.RaycastHit2D[])
extern void PhysicsScene2D_Raycast_mE0460FE0CEE7076962DC2983A7B0DBB757DB133A_AdjustorThunk (void);
// 0x0000000B System.Int32 UnityEngine.PhysicsScene2D::RaycastArray_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector2,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D,UnityEngine.RaycastHit2D[])
extern void PhysicsScene2D_RaycastArray_Internal_m40B8BDD4BE4D95E3826334DA2A8E31EBAD7B6E8D (void);
// 0x0000000C System.Int32 UnityEngine.PhysicsScene2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D,System.Collections.Generic.List`1<UnityEngine.RaycastHit2D>)
extern void PhysicsScene2D_Raycast_mC5642256C2119435B87AD87ED30086973D9F3A24_AdjustorThunk (void);
// 0x0000000D System.Int32 UnityEngine.PhysicsScene2D::RaycastList_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector2,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D,System.Collections.Generic.List`1<UnityEngine.RaycastHit2D>)
extern void PhysicsScene2D_RaycastList_Internal_m4D2446707FAC9EC36975B8119616F30BB724EA09 (void);
// 0x0000000E UnityEngine.RaycastHit2D UnityEngine.PhysicsScene2D::CircleCast(UnityEngine.Vector2,System.Single,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D)
extern void PhysicsScene2D_CircleCast_m1C2832077F998EAAEAE1AD3FC0E309394A9F1378_AdjustorThunk (void);
// 0x0000000F UnityEngine.RaycastHit2D UnityEngine.PhysicsScene2D::CircleCast_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector2,System.Single,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D)
extern void PhysicsScene2D_CircleCast_Internal_mDA9D13E0B4AF76BF098C234C04AC754D3FAEA85C (void);
// 0x00000010 System.Int32 UnityEngine.PhysicsScene2D::GetRayIntersection(UnityEngine.Ray,System.Single,UnityEngine.RaycastHit2D[],System.Int32)
extern void PhysicsScene2D_GetRayIntersection_m2DB850378F1910BFC62243A1A33D8B17738882EC_AdjustorThunk (void);
// 0x00000011 System.Int32 UnityEngine.PhysicsScene2D::GetRayIntersectionArray_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Int32,UnityEngine.RaycastHit2D[])
extern void PhysicsScene2D_GetRayIntersectionArray_Internal_m1A9DC1520B80AF8444C38FEEDEB40EDD405805A5 (void);
// 0x00000012 System.Int32 UnityEngine.PhysicsScene2D::OverlapCircle(UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D,UnityEngine.Collider2D[])
extern void PhysicsScene2D_OverlapCircle_m204738F4E5D2E9923E1671E5E15750A7641F7950_AdjustorThunk (void);
// 0x00000013 System.Int32 UnityEngine.PhysicsScene2D::OverlapCircleArray_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D,UnityEngine.Collider2D[])
extern void PhysicsScene2D_OverlapCircleArray_Internal_mB9277F0D2860FB4D2E1734CB01460BA48937397F (void);
// 0x00000014 System.Void UnityEngine.PhysicsScene2D::Linecast_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector2&,UnityEngine.Vector2&,UnityEngine.ContactFilter2D&,UnityEngine.RaycastHit2D&)
extern void PhysicsScene2D_Linecast_Internal_Injected_m938299D4FDCC6A113129311178FAADDA5CEA7D90 (void);
// 0x00000015 System.Void UnityEngine.PhysicsScene2D::Raycast_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector2&,UnityEngine.Vector2&,System.Single,UnityEngine.ContactFilter2D&,UnityEngine.RaycastHit2D&)
extern void PhysicsScene2D_Raycast_Internal_Injected_m197B563F302D9E7C336EE7BB0A356F6785F1584A (void);
// 0x00000016 System.Int32 UnityEngine.PhysicsScene2D::RaycastArray_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector2&,UnityEngine.Vector2&,System.Single,UnityEngine.ContactFilter2D&,UnityEngine.RaycastHit2D[])
extern void PhysicsScene2D_RaycastArray_Internal_Injected_mC5FDF82692390ECAB17CF821D25349A66B3C8143 (void);
// 0x00000017 System.Int32 UnityEngine.PhysicsScene2D::RaycastList_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector2&,UnityEngine.Vector2&,System.Single,UnityEngine.ContactFilter2D&,System.Collections.Generic.List`1<UnityEngine.RaycastHit2D>)
extern void PhysicsScene2D_RaycastList_Internal_Injected_mD8495122B2F8BD1194E83CA20DFC005D414C707B (void);
// 0x00000018 System.Void UnityEngine.PhysicsScene2D::CircleCast_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector2&,System.Single,UnityEngine.Vector2&,System.Single,UnityEngine.ContactFilter2D&,UnityEngine.RaycastHit2D&)
extern void PhysicsScene2D_CircleCast_Internal_Injected_m8D9ABBE523F1C5D398A9EFD599A7F14D8EB4EE24 (void);
// 0x00000019 System.Int32 UnityEngine.PhysicsScene2D::GetRayIntersectionArray_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single,System.Int32,UnityEngine.RaycastHit2D[])
extern void PhysicsScene2D_GetRayIntersectionArray_Internal_Injected_m74194745127DA849411A2191EE7C52EB07BB21A9 (void);
// 0x0000001A System.Int32 UnityEngine.PhysicsScene2D::OverlapCircleArray_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector2&,System.Single,UnityEngine.ContactFilter2D&,UnityEngine.Collider2D[])
extern void PhysicsScene2D_OverlapCircleArray_Internal_Injected_mC8CA0F2C5DE4CD6B39A56011400C63F2958E5674 (void);
// 0x0000001B UnityEngine.PhysicsScene2D UnityEngine.Physics2D::get_defaultPhysicsScene()
extern void Physics2D_get_defaultPhysicsScene_m2C9DA4DFAFB71332EC48E50CCB16275441CADE84 (void);
// 0x0000001C System.Boolean UnityEngine.Physics2D::get_queriesHitTriggers()
extern void Physics2D_get_queriesHitTriggers_m8BB98B1754A86777B4D58A4F28F63E8EC77B031B (void);
// 0x0000001D UnityEngine.RaycastHit2D UnityEngine.Physics2D::Linecast(UnityEngine.Vector2,UnityEngine.Vector2,System.Int32)
extern void Physics2D_Linecast_m720F975685497285E077F5FE20480ED441528AEA (void);
// 0x0000001E UnityEngine.RaycastHit2D UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Physics2D_Raycast_mD22D6BC52ACAB22598A720525B3840C019842FFC (void);
// 0x0000001F UnityEngine.RaycastHit2D UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single)
extern void Physics2D_Raycast_m468BF2D74BED92728533EA2108830C44ED93A0EF (void);
// 0x00000020 UnityEngine.RaycastHit2D UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32)
extern void Physics2D_Raycast_mBEB66E9AA034BD0AE1B1C99DF872247B0131CBDD (void);
// 0x00000021 UnityEngine.RaycastHit2D UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32,System.Single)
extern void Physics2D_Raycast_mB43742B1077F487D1458388C5B11EE46D73533C0 (void);
// 0x00000022 UnityEngine.RaycastHit2D UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32,System.Single,System.Single)
extern void Physics2D_Raycast_m4803AD692674FEE7EE269A6170AD5CEFEA6D3D78 (void);
// 0x00000023 System.Int32 UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.ContactFilter2D,UnityEngine.RaycastHit2D[])
extern void Physics2D_Raycast_m0C22B1CACFA7E2A16D731B6E2D9D2ABC0666CCCE (void);
// 0x00000024 System.Int32 UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.ContactFilter2D,UnityEngine.RaycastHit2D[],System.Single)
extern void Physics2D_Raycast_m8678AB161A71C09D7606299D194A90BA814BA543 (void);
// 0x00000025 System.Int32 UnityEngine.Physics2D::Raycast(UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.ContactFilter2D,System.Collections.Generic.List`1<UnityEngine.RaycastHit2D>,System.Single)
extern void Physics2D_Raycast_m940284F559A12F0594CF6E1A20583F7EA67E8645 (void);
// 0x00000026 UnityEngine.RaycastHit2D UnityEngine.Physics2D::CircleCast(UnityEngine.Vector2,System.Single,UnityEngine.Vector2,System.Single,System.Int32)
extern void Physics2D_CircleCast_mC8B2427D0713166B3B6F0A0C03A3A03CA3963567 (void);
// 0x00000027 UnityEngine.RaycastHit2D[] UnityEngine.Physics2D::GetRayIntersectionAll(UnityEngine.Ray)
extern void Physics2D_GetRayIntersectionAll_mBD650C3EA6E692CE3E1255B6EAADF659307012D8 (void);
// 0x00000028 UnityEngine.RaycastHit2D[] UnityEngine.Physics2D::GetRayIntersectionAll(UnityEngine.Ray,System.Single)
extern void Physics2D_GetRayIntersectionAll_mACC24DD73E1388C1DF86847390B89A5B0223F03A (void);
// 0x00000029 UnityEngine.RaycastHit2D[] UnityEngine.Physics2D::GetRayIntersectionAll(UnityEngine.Ray,System.Single,System.Int32)
extern void Physics2D_GetRayIntersectionAll_m04BCAB03333B049C48BE61036E512E12A5FBD053 (void);
// 0x0000002A UnityEngine.RaycastHit2D[] UnityEngine.Physics2D::GetRayIntersectionAll_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector3,UnityEngine.Vector3,System.Single,System.Int32)
extern void Physics2D_GetRayIntersectionAll_Internal_m4E68866CF4A79A58DBF4B8A355D3EEE62BEF6612 (void);
// 0x0000002B System.Int32 UnityEngine.Physics2D::GetRayIntersectionNonAlloc(UnityEngine.Ray,UnityEngine.RaycastHit2D[])
extern void Physics2D_GetRayIntersectionNonAlloc_m5F1AF31EEB67FE97AD2C40C102914371C2E825F0 (void);
// 0x0000002C System.Int32 UnityEngine.Physics2D::GetRayIntersectionNonAlloc(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single)
extern void Physics2D_GetRayIntersectionNonAlloc_m1A638894F08E9F401C7161D02171805B4897B51E (void);
// 0x0000002D System.Int32 UnityEngine.Physics2D::GetRayIntersectionNonAlloc(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single,System.Int32)
extern void Physics2D_GetRayIntersectionNonAlloc_m3817EA2CC7B95C89683ACE0E433D6D4C6735CA0A (void);
// 0x0000002E UnityEngine.Collider2D[] UnityEngine.Physics2D::OverlapCircleAll(UnityEngine.Vector2,System.Single,System.Int32)
extern void Physics2D_OverlapCircleAll_m9711B169E5705A2B07AF64095E8271CD21E05FD8 (void);
// 0x0000002F UnityEngine.Collider2D[] UnityEngine.Physics2D::OverlapCircleAll_Internal(UnityEngine.PhysicsScene2D,UnityEngine.Vector2,System.Single,UnityEngine.ContactFilter2D)
extern void Physics2D_OverlapCircleAll_Internal_m0542CFE7F662C028FFCD91A68AF5907F963AC889 (void);
// 0x00000030 System.Int32 UnityEngine.Physics2D::OverlapCircleNonAlloc(UnityEngine.Vector2,System.Single,UnityEngine.Collider2D[],System.Int32)
extern void Physics2D_OverlapCircleNonAlloc_m8D3FC6E89FFE478503BD703AB00BE8FB6F3C1357 (void);
// 0x00000031 System.Void UnityEngine.Physics2D::.cctor()
extern void Physics2D__cctor_mC0D622F2EAF13BF0513DB2969E50EEC5631CDBFC (void);
// 0x00000032 UnityEngine.RaycastHit2D[] UnityEngine.Physics2D::GetRayIntersectionAll_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector3&,UnityEngine.Vector3&,System.Single,System.Int32)
extern void Physics2D_GetRayIntersectionAll_Internal_Injected_m8B627D4448B34665FC8BCF560EE851152FE2D15A (void);
// 0x00000033 UnityEngine.Collider2D[] UnityEngine.Physics2D::OverlapCircleAll_Internal_Injected(UnityEngine.PhysicsScene2D&,UnityEngine.Vector2&,System.Single,UnityEngine.ContactFilter2D&)
extern void Physics2D_OverlapCircleAll_Internal_Injected_mEFD991E51C0EC3EB5BD1BF01E06E98E115E62398 (void);
// 0x00000034 System.Void UnityEngine.ContactFilter2D::CheckConsistency()
extern void ContactFilter2D_CheckConsistency_m0E1FC7D646C418F545F778197348F97ADA5409A2_AdjustorThunk (void);
// 0x00000035 System.Void UnityEngine.ContactFilter2D::SetLayerMask(UnityEngine.LayerMask)
extern void ContactFilter2D_SetLayerMask_mECEE981A09393F1097555D46449ED7CA4D8659E6_AdjustorThunk (void);
// 0x00000036 System.Void UnityEngine.ContactFilter2D::SetDepth(System.Single,System.Single)
extern void ContactFilter2D_SetDepth_mF4AB9C380EDC3726D58734010BD90AD7D36ABDB0_AdjustorThunk (void);
// 0x00000037 UnityEngine.ContactFilter2D UnityEngine.ContactFilter2D::CreateLegacyFilter(System.Int32,System.Single,System.Single)
extern void ContactFilter2D_CreateLegacyFilter_mA52A1C54BA7C4A49094B172BE7FA6044EF346A51 (void);
// 0x00000038 System.Void UnityEngine.ContactFilter2D::CheckConsistency_Injected(UnityEngine.ContactFilter2D&)
extern void ContactFilter2D_CheckConsistency_Injected_m4640AA8896FEFE90396C5B47C4FE07930DA918BE (void);
// 0x00000039 UnityEngine.Collider2D UnityEngine.Collision2D::get_collider()
extern void Collision2D_get_collider_m8767ED466970D214201582C37D90F2CD4BEFD6D2 (void);
// 0x0000003A UnityEngine.Rigidbody2D UnityEngine.Collision2D::get_rigidbody()
extern void Collision2D_get_rigidbody_m7344D69B114D326F6866C0F02E5152CBE5C8B5BB (void);
// 0x0000003B UnityEngine.GameObject UnityEngine.Collision2D::get_gameObject()
extern void Collision2D_get_gameObject_m209F9F15585DE3F9270E0D9BFB050950AD301A5F (void);
// 0x0000003C UnityEngine.Vector2 UnityEngine.RaycastHit2D::get_point()
extern void RaycastHit2D_get_point_mC567E234B1B673C3A9819023C3DC97C781443098_AdjustorThunk (void);
// 0x0000003D UnityEngine.Vector2 UnityEngine.RaycastHit2D::get_normal()
extern void RaycastHit2D_get_normal_m9F0974E4514AD56C00FCF6FF4CDF10AED62FE6E4_AdjustorThunk (void);
// 0x0000003E System.Single UnityEngine.RaycastHit2D::get_distance()
extern void RaycastHit2D_get_distance_m2D9F391717ECACFDA8E01A4126E0F8F59F7E774F_AdjustorThunk (void);
// 0x0000003F UnityEngine.Collider2D UnityEngine.RaycastHit2D::get_collider()
extern void RaycastHit2D_get_collider_m6A7EC53B2E179C2EFF4F29018A132B2979CBE976_AdjustorThunk (void);
// 0x00000040 UnityEngine.Rigidbody2D UnityEngine.RaycastHit2D::get_rigidbody()
extern void RaycastHit2D_get_rigidbody_mE6D43BB62B41529F1FF3A66615C571B418662F47_AdjustorThunk (void);
// 0x00000041 UnityEngine.Transform UnityEngine.RaycastHit2D::get_transform()
extern void RaycastHit2D_get_transform_m9AD59D59FC4F85128F139C0DE9B0A2AE27D75DAC_AdjustorThunk (void);
// 0x00000042 System.Boolean UnityEngine.RaycastHit2D::op_Implicit(UnityEngine.RaycastHit2D)
extern void RaycastHit2D_op_Implicit_mCA78D022D288340F86A780916B7FDC515BF816CF (void);
// 0x00000043 System.Void UnityEngine.Rigidbody2D::.ctor()
extern void Rigidbody2D__ctor_mEADC6DF3297B27BF8DAE647A5D3384CA80E005FB (void);
// 0x00000044 UnityEngine.Vector2 UnityEngine.Collider2D::get_offset()
extern void Collider2D_get_offset_mCB3DEFB9ACB05211320B8406B01F089EF7F8788D (void);
// 0x00000045 System.Void UnityEngine.Collider2D::set_offset(UnityEngine.Vector2)
extern void Collider2D_set_offset_mC752F6CA4C47C5543538BA3BC9B04A3D267AAC6C (void);
// 0x00000046 UnityEngine.Rigidbody2D UnityEngine.Collider2D::get_attachedRigidbody()
extern void Collider2D_get_attachedRigidbody_m7BBA6D4F834B78D334349066540EA4DDDE4F0308 (void);
// 0x00000047 UnityEngine.Bounds UnityEngine.Collider2D::get_bounds()
extern void Collider2D_get_bounds_mB13BA419529917B7F97F5EFC599D8D92B0603359 (void);
// 0x00000048 System.Void UnityEngine.Collider2D::.ctor()
extern void Collider2D__ctor_m9E497E4A527D5ADD864AB3D7901A4087C45712C0 (void);
// 0x00000049 System.Void UnityEngine.Collider2D::get_offset_Injected(UnityEngine.Vector2&)
extern void Collider2D_get_offset_Injected_mFBEEA538206330D2D4C62A04DF339332596C0F97 (void);
// 0x0000004A System.Void UnityEngine.Collider2D::set_offset_Injected(UnityEngine.Vector2&)
extern void Collider2D_set_offset_Injected_m98CB990275094E1261101B082C51DDD634CA0A79 (void);
// 0x0000004B System.Void UnityEngine.Collider2D::get_bounds_Injected(UnityEngine.Bounds&)
extern void Collider2D_get_bounds_Injected_mBABA06A9F645F3A24D7272B868B1782814E21A98 (void);
// 0x0000004C System.Single UnityEngine.CircleCollider2D::get_radius()
extern void CircleCollider2D_get_radius_m016333FD7A5A5FD84FEFD7D02B57D4CA728EFA27 (void);
// 0x0000004D System.Void UnityEngine.CircleCollider2D::set_radius(System.Single)
extern void CircleCollider2D_set_radius_mC4F6C9D9583045A5117C269D7CF4E9E8D85D1A19 (void);
// 0x0000004E UnityEngine.Vector2 UnityEngine.BoxCollider2D::get_size()
extern void BoxCollider2D_get_size_m6230015317115D9BED5C61A4EDAC013C8A7664E1 (void);
// 0x0000004F System.Void UnityEngine.BoxCollider2D::set_size(UnityEngine.Vector2)
extern void BoxCollider2D_set_size_mFA630C4BD41F786D208C1C0382A7FCF7868BA489 (void);
// 0x00000050 System.Void UnityEngine.BoxCollider2D::get_size_Injected(UnityEngine.Vector2&)
extern void BoxCollider2D_get_size_Injected_m6E18F627969D38CF513DB4CF680ACD51810F74CD (void);
// 0x00000051 System.Void UnityEngine.BoxCollider2D::set_size_Injected(UnityEngine.Vector2&)
extern void BoxCollider2D_set_size_Injected_mB787996D8E2E7919FE975BC435677115539A53A0 (void);
static Il2CppMethodPointer s_methodPointers[81] = 
{
	PhysicsScene2D_ToString_m6F48AC6CE0D8540FCE4914ABB78ED0BAF0D83CBE_AdjustorThunk,
	PhysicsScene2D_GetHashCode_mB1C0E9E977ACCBF0AA0D266E5851B4D778354467_AdjustorThunk,
	PhysicsScene2D_Equals_mA91E96FDE086CF876D4D469CBFF0D43400C834E8_AdjustorThunk,
	PhysicsScene2D_Equals_mAA6F413AD3CDDD052496FAF69C34A45CA25D4293_AdjustorThunk,
	PhysicsScene2D_Linecast_mFE9838D8AE5569DEDBF8DA9E4E7CE54524D96C9F_AdjustorThunk,
	PhysicsScene2D_Linecast_Internal_mB1FEA3F9760D1E2AB59ABE8E17C93681E55770C2,
	PhysicsScene2D_Raycast_m8A048506EDDC5C968DB55584FBF650DAB3BCB987_AdjustorThunk,
	PhysicsScene2D_Raycast_mFA61658E024A98E2A7BC1B6965E9E5537DCA2DB8_AdjustorThunk,
	PhysicsScene2D_Raycast_Internal_mB24F5D2B6967C70371484EA703E16346DBFD0718,
	PhysicsScene2D_Raycast_mE0460FE0CEE7076962DC2983A7B0DBB757DB133A_AdjustorThunk,
	PhysicsScene2D_RaycastArray_Internal_m40B8BDD4BE4D95E3826334DA2A8E31EBAD7B6E8D,
	PhysicsScene2D_Raycast_mC5642256C2119435B87AD87ED30086973D9F3A24_AdjustorThunk,
	PhysicsScene2D_RaycastList_Internal_m4D2446707FAC9EC36975B8119616F30BB724EA09,
	PhysicsScene2D_CircleCast_m1C2832077F998EAAEAE1AD3FC0E309394A9F1378_AdjustorThunk,
	PhysicsScene2D_CircleCast_Internal_mDA9D13E0B4AF76BF098C234C04AC754D3FAEA85C,
	PhysicsScene2D_GetRayIntersection_m2DB850378F1910BFC62243A1A33D8B17738882EC_AdjustorThunk,
	PhysicsScene2D_GetRayIntersectionArray_Internal_m1A9DC1520B80AF8444C38FEEDEB40EDD405805A5,
	PhysicsScene2D_OverlapCircle_m204738F4E5D2E9923E1671E5E15750A7641F7950_AdjustorThunk,
	PhysicsScene2D_OverlapCircleArray_Internal_mB9277F0D2860FB4D2E1734CB01460BA48937397F,
	PhysicsScene2D_Linecast_Internal_Injected_m938299D4FDCC6A113129311178FAADDA5CEA7D90,
	PhysicsScene2D_Raycast_Internal_Injected_m197B563F302D9E7C336EE7BB0A356F6785F1584A,
	PhysicsScene2D_RaycastArray_Internal_Injected_mC5FDF82692390ECAB17CF821D25349A66B3C8143,
	PhysicsScene2D_RaycastList_Internal_Injected_mD8495122B2F8BD1194E83CA20DFC005D414C707B,
	PhysicsScene2D_CircleCast_Internal_Injected_m8D9ABBE523F1C5D398A9EFD599A7F14D8EB4EE24,
	PhysicsScene2D_GetRayIntersectionArray_Internal_Injected_m74194745127DA849411A2191EE7C52EB07BB21A9,
	PhysicsScene2D_OverlapCircleArray_Internal_Injected_mC8CA0F2C5DE4CD6B39A56011400C63F2958E5674,
	Physics2D_get_defaultPhysicsScene_m2C9DA4DFAFB71332EC48E50CCB16275441CADE84,
	Physics2D_get_queriesHitTriggers_m8BB98B1754A86777B4D58A4F28F63E8EC77B031B,
	Physics2D_Linecast_m720F975685497285E077F5FE20480ED441528AEA,
	Physics2D_Raycast_mD22D6BC52ACAB22598A720525B3840C019842FFC,
	Physics2D_Raycast_m468BF2D74BED92728533EA2108830C44ED93A0EF,
	Physics2D_Raycast_mBEB66E9AA034BD0AE1B1C99DF872247B0131CBDD,
	Physics2D_Raycast_mB43742B1077F487D1458388C5B11EE46D73533C0,
	Physics2D_Raycast_m4803AD692674FEE7EE269A6170AD5CEFEA6D3D78,
	Physics2D_Raycast_m0C22B1CACFA7E2A16D731B6E2D9D2ABC0666CCCE,
	Physics2D_Raycast_m8678AB161A71C09D7606299D194A90BA814BA543,
	Physics2D_Raycast_m940284F559A12F0594CF6E1A20583F7EA67E8645,
	Physics2D_CircleCast_mC8B2427D0713166B3B6F0A0C03A3A03CA3963567,
	Physics2D_GetRayIntersectionAll_mBD650C3EA6E692CE3E1255B6EAADF659307012D8,
	Physics2D_GetRayIntersectionAll_mACC24DD73E1388C1DF86847390B89A5B0223F03A,
	Physics2D_GetRayIntersectionAll_m04BCAB03333B049C48BE61036E512E12A5FBD053,
	Physics2D_GetRayIntersectionAll_Internal_m4E68866CF4A79A58DBF4B8A355D3EEE62BEF6612,
	Physics2D_GetRayIntersectionNonAlloc_m5F1AF31EEB67FE97AD2C40C102914371C2E825F0,
	Physics2D_GetRayIntersectionNonAlloc_m1A638894F08E9F401C7161D02171805B4897B51E,
	Physics2D_GetRayIntersectionNonAlloc_m3817EA2CC7B95C89683ACE0E433D6D4C6735CA0A,
	Physics2D_OverlapCircleAll_m9711B169E5705A2B07AF64095E8271CD21E05FD8,
	Physics2D_OverlapCircleAll_Internal_m0542CFE7F662C028FFCD91A68AF5907F963AC889,
	Physics2D_OverlapCircleNonAlloc_m8D3FC6E89FFE478503BD703AB00BE8FB6F3C1357,
	Physics2D__cctor_mC0D622F2EAF13BF0513DB2969E50EEC5631CDBFC,
	Physics2D_GetRayIntersectionAll_Internal_Injected_m8B627D4448B34665FC8BCF560EE851152FE2D15A,
	Physics2D_OverlapCircleAll_Internal_Injected_mEFD991E51C0EC3EB5BD1BF01E06E98E115E62398,
	ContactFilter2D_CheckConsistency_m0E1FC7D646C418F545F778197348F97ADA5409A2_AdjustorThunk,
	ContactFilter2D_SetLayerMask_mECEE981A09393F1097555D46449ED7CA4D8659E6_AdjustorThunk,
	ContactFilter2D_SetDepth_mF4AB9C380EDC3726D58734010BD90AD7D36ABDB0_AdjustorThunk,
	ContactFilter2D_CreateLegacyFilter_mA52A1C54BA7C4A49094B172BE7FA6044EF346A51,
	ContactFilter2D_CheckConsistency_Injected_m4640AA8896FEFE90396C5B47C4FE07930DA918BE,
	Collision2D_get_collider_m8767ED466970D214201582C37D90F2CD4BEFD6D2,
	Collision2D_get_rigidbody_m7344D69B114D326F6866C0F02E5152CBE5C8B5BB,
	Collision2D_get_gameObject_m209F9F15585DE3F9270E0D9BFB050950AD301A5F,
	RaycastHit2D_get_point_mC567E234B1B673C3A9819023C3DC97C781443098_AdjustorThunk,
	RaycastHit2D_get_normal_m9F0974E4514AD56C00FCF6FF4CDF10AED62FE6E4_AdjustorThunk,
	RaycastHit2D_get_distance_m2D9F391717ECACFDA8E01A4126E0F8F59F7E774F_AdjustorThunk,
	RaycastHit2D_get_collider_m6A7EC53B2E179C2EFF4F29018A132B2979CBE976_AdjustorThunk,
	RaycastHit2D_get_rigidbody_mE6D43BB62B41529F1FF3A66615C571B418662F47_AdjustorThunk,
	RaycastHit2D_get_transform_m9AD59D59FC4F85128F139C0DE9B0A2AE27D75DAC_AdjustorThunk,
	RaycastHit2D_op_Implicit_mCA78D022D288340F86A780916B7FDC515BF816CF,
	Rigidbody2D__ctor_mEADC6DF3297B27BF8DAE647A5D3384CA80E005FB,
	Collider2D_get_offset_mCB3DEFB9ACB05211320B8406B01F089EF7F8788D,
	Collider2D_set_offset_mC752F6CA4C47C5543538BA3BC9B04A3D267AAC6C,
	Collider2D_get_attachedRigidbody_m7BBA6D4F834B78D334349066540EA4DDDE4F0308,
	Collider2D_get_bounds_mB13BA419529917B7F97F5EFC599D8D92B0603359,
	Collider2D__ctor_m9E497E4A527D5ADD864AB3D7901A4087C45712C0,
	Collider2D_get_offset_Injected_mFBEEA538206330D2D4C62A04DF339332596C0F97,
	Collider2D_set_offset_Injected_m98CB990275094E1261101B082C51DDD634CA0A79,
	Collider2D_get_bounds_Injected_mBABA06A9F645F3A24D7272B868B1782814E21A98,
	CircleCollider2D_get_radius_m016333FD7A5A5FD84FEFD7D02B57D4CA728EFA27,
	CircleCollider2D_set_radius_mC4F6C9D9583045A5117C269D7CF4E9E8D85D1A19,
	BoxCollider2D_get_size_m6230015317115D9BED5C61A4EDAC013C8A7664E1,
	BoxCollider2D_set_size_mFA630C4BD41F786D208C1C0382A7FCF7868BA489,
	BoxCollider2D_get_size_Injected_m6E18F627969D38CF513DB4CF680ACD51810F74CD,
	BoxCollider2D_set_size_Injected_mB787996D8E2E7919FE975BC435677115539A53A0,
};
static const int32_t s_InvokerIndices[81] = 
{
	14,
	10,
	9,
	1726,
	1727,
	1728,
	1729,
	1730,
	1731,
	1732,
	1733,
	1732,
	1733,
	1734,
	1735,
	1736,
	1737,
	1738,
	1739,
	1740,
	1741,
	1742,
	1742,
	1743,
	1744,
	1745,
	1746,
	49,
	1747,
	1748,
	1749,
	1750,
	1751,
	1752,
	1753,
	1754,
	1754,
	1755,
	1634,
	1633,
	1632,
	1756,
	1638,
	1637,
	1636,
	1757,
	1758,
	1759,
	3,
	1760,
	1761,
	23,
	1762,
	1303,
	1763,
	17,
	14,
	14,
	14,
	1191,
	1191,
	689,
	14,
	14,
	14,
	1764,
	23,
	1191,
	1192,
	14,
	1215,
	23,
	6,
	6,
	6,
	689,
	298,
	1191,
	1192,
	6,
	6,
};
extern const Il2CppCodeGenModule g_UnityEngine_Physics2DModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_Physics2DModuleCodeGenModule = 
{
	"UnityEngine.Physics2DModule.dll",
	81,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
