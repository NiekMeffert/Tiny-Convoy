﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.AndroidJavaRunnable::.ctor(System.Object,System.IntPtr)
extern void AndroidJavaRunnable__ctor_mF5ED3CD9300D6D702748378A0E0633612866D052 (void);
// 0x00000002 System.Void UnityEngine.AndroidJavaRunnable::Invoke()
extern void AndroidJavaRunnable_Invoke_m98A444239D449E61110C80E5F18D3C1D386FE79B (void);
// 0x00000003 System.IAsyncResult UnityEngine.AndroidJavaRunnable::BeginInvoke(System.AsyncCallback,System.Object)
extern void AndroidJavaRunnable_BeginInvoke_mC020AAC7B0B350E65DDA128222B54D5B10FE43ED (void);
// 0x00000004 System.Void UnityEngine.AndroidJavaRunnable::EndInvoke(System.IAsyncResult)
extern void AndroidJavaRunnable_EndInvoke_m4301C1FBD81C209F7056166325A35617DD10B5E9 (void);
// 0x00000005 System.Void UnityEngine.AndroidJavaException::.ctor(System.String,System.String)
extern void AndroidJavaException__ctor_m8E5216F0181090FB7A9016AED78B7935019791D8 (void);
// 0x00000006 System.String UnityEngine.AndroidJavaException::get_StackTrace()
extern void AndroidJavaException_get_StackTrace_m0CBD35F72DF136212F27E63C3BAF4FB7D956C710 (void);
// 0x00000007 System.Void UnityEngine.GlobalJavaObjectRef::.ctor(System.IntPtr)
extern void GlobalJavaObjectRef__ctor_m5581A68DC5217545E13F48ACF2DAFD9DF30396BC (void);
// 0x00000008 System.Void UnityEngine.GlobalJavaObjectRef::Finalize()
extern void GlobalJavaObjectRef_Finalize_mAC26B588678FAB49013BFD07E5090E438E016F83 (void);
// 0x00000009 System.IntPtr UnityEngine.GlobalJavaObjectRef::op_Implicit(UnityEngine.GlobalJavaObjectRef)
extern void GlobalJavaObjectRef_op_Implicit_m1F52DE72C8F8B11E651F8B31879ED5AFD413EDFF (void);
// 0x0000000A System.Void UnityEngine.GlobalJavaObjectRef::Dispose()
extern void GlobalJavaObjectRef_Dispose_mDCFD34D040E7B4ACE886336F3659316D1A45599F (void);
// 0x0000000B System.Void UnityEngine.AndroidJavaRunnableProxy::.ctor(UnityEngine.AndroidJavaRunnable)
extern void AndroidJavaRunnableProxy__ctor_m0D23BFCE5D99EA0AA56A5813B2E91BDDAD72C738 (void);
// 0x0000000C System.Void UnityEngine.AndroidJavaProxy::.ctor(System.String)
extern void AndroidJavaProxy__ctor_m159565DEF4041D92C0763D1F4A0684140241CD9A (void);
// 0x0000000D System.Void UnityEngine.AndroidJavaProxy::.ctor(UnityEngine.AndroidJavaClass)
extern void AndroidJavaProxy__ctor_m9A2D1F4BF0E7803070D68D3C386F4218D3BCAC0F (void);
// 0x0000000E System.Void UnityEngine.AndroidJavaProxy::Finalize()
extern void AndroidJavaProxy_Finalize_mB53473746276958436FE45332CD82C6847F14D73 (void);
// 0x0000000F UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::Invoke(System.String,System.Object[])
extern void AndroidJavaProxy_Invoke_m2A4BA59C6A517E0B692478676AA0A0A77980848E (void);
// 0x00000010 UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::Invoke(System.String,UnityEngine.AndroidJavaObject[])
extern void AndroidJavaProxy_Invoke_m27ACB084BB434FFEA8A1FB687CCB332F4EB80B9B (void);
// 0x00000011 UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaProxy::GetProxyObject()
extern void AndroidJavaProxy_GetProxyObject_m411DC59BF56152B6058ABF99BBC8B64C813EEF06 (void);
// 0x00000012 System.IntPtr UnityEngine.AndroidJavaProxy::GetRawProxy()
extern void AndroidJavaProxy_GetRawProxy_mFE7D48E72D4744E260D3ACE6D777D072002BEA6C (void);
// 0x00000013 System.Void UnityEngine.AndroidJavaProxy::.cctor()
extern void AndroidJavaProxy__cctor_mC5B6251AA25617F7CE1AD4DAD0BD2CCAC9636C9F (void);
// 0x00000014 System.Void UnityEngine.AndroidJavaObject::.ctor(System.String,System.Object[])
extern void AndroidJavaObject__ctor_m39462EAD9AD82CBD90DEB4B7127F3D6C87A02BFA (void);
// 0x00000015 System.Void UnityEngine.AndroidJavaObject::Dispose()
extern void AndroidJavaObject_Dispose_m02D1B6D8F3E902E5F0D181BF6C1753856B0DE144 (void);
// 0x00000016 System.IntPtr UnityEngine.AndroidJavaObject::GetRawObject()
extern void AndroidJavaObject_GetRawObject_mCEB7EEC51D62A3E4F0D6F62C08CBEF008B556F3D (void);
// 0x00000017 System.IntPtr UnityEngine.AndroidJavaObject::GetRawClass()
extern void AndroidJavaObject_GetRawClass_m28BFE7AD6A4FFCB45929D9D1A0F8D792C3974774 (void);
// 0x00000018 ReturnType UnityEngine.AndroidJavaObject::Call(System.String,System.Object[])
// 0x00000019 ReturnType UnityEngine.AndroidJavaObject::CallStatic(System.String,System.Object[])
// 0x0000001A System.Void UnityEngine.AndroidJavaObject::DebugPrint(System.String)
extern void AndroidJavaObject_DebugPrint_m88F06202527BA5A2848C1533C8B396702D112531 (void);
// 0x0000001B System.Void UnityEngine.AndroidJavaObject::_AndroidJavaObject(System.String,System.Object[])
extern void AndroidJavaObject__AndroidJavaObject_m596F928EE49384D7C7455920BA6ADFB2D9540CFA (void);
// 0x0000001C System.Void UnityEngine.AndroidJavaObject::.ctor(System.IntPtr)
extern void AndroidJavaObject__ctor_m22E1E2E5D9F3DA31FF7DFB1339AD3BB0C3813E80 (void);
// 0x0000001D System.Void UnityEngine.AndroidJavaObject::.ctor()
extern void AndroidJavaObject__ctor_m4C0CDAB96B807BB04E2C43609F16865034A60001 (void);
// 0x0000001E System.Void UnityEngine.AndroidJavaObject::Finalize()
extern void AndroidJavaObject_Finalize_m834AA4594A7070A6DE1CA884752D2928ACAF2AF0 (void);
// 0x0000001F System.Void UnityEngine.AndroidJavaObject::Dispose(System.Boolean)
extern void AndroidJavaObject_Dispose_m5F40DCA32137A2280BE224A63A89B8FE637619DA (void);
// 0x00000020 ReturnType UnityEngine.AndroidJavaObject::_Call(System.String,System.Object[])
// 0x00000021 ReturnType UnityEngine.AndroidJavaObject::_CallStatic(System.String,System.Object[])
// 0x00000022 UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::AndroidJavaObjectDeleteLocalRef(System.IntPtr)
extern void AndroidJavaObject_AndroidJavaObjectDeleteLocalRef_m0B0BCBDD56C299AC69938BDD4135E1B6EEAAC7EF (void);
// 0x00000023 UnityEngine.AndroidJavaClass UnityEngine.AndroidJavaObject::AndroidJavaClassDeleteLocalRef(System.IntPtr)
extern void AndroidJavaObject_AndroidJavaClassDeleteLocalRef_mD137411129D4E0B5AB858EAE367EBBA0E668D962 (void);
// 0x00000024 System.IntPtr UnityEngine.AndroidJavaObject::_GetRawObject()
extern void AndroidJavaObject__GetRawObject_m4B415E770E265AE32F5523DF0E627626F77E572F (void);
// 0x00000025 System.IntPtr UnityEngine.AndroidJavaObject::_GetRawClass()
extern void AndroidJavaObject__GetRawClass_m1B3729CDBBC212E0C706256FF16D2F437F618435 (void);
// 0x00000026 System.Void UnityEngine.AndroidJavaObject::.cctor()
extern void AndroidJavaObject__cctor_m46EF3B9E61C141E07E12762F96F777EA8D1A4629 (void);
// 0x00000027 System.Void UnityEngine.AndroidJavaClass::.ctor(System.String)
extern void AndroidJavaClass__ctor_mAE416E812DB3911279C0FE87A7760247CE1BBFA8 (void);
// 0x00000028 System.Void UnityEngine.AndroidJavaClass::_AndroidJavaClass(System.String)
extern void AndroidJavaClass__AndroidJavaClass_mBF3C92E82722125793A66F20C92BAE17F0CB02D9 (void);
// 0x00000029 System.Void UnityEngine.AndroidJavaClass::.ctor(System.IntPtr)
extern void AndroidJavaClass__ctor_m44A6DEC0612D768E9947FFC1C2DA64D0605F34F1 (void);
// 0x0000002A System.Boolean UnityEngine.AndroidReflection::IsPrimitive(System.Type)
extern void AndroidReflection_IsPrimitive_m4C75B1AAEDD3FA0F73AFBC83CB374D3D8A9A3749 (void);
// 0x0000002B System.Boolean UnityEngine.AndroidReflection::IsAssignableFrom(System.Type,System.Type)
extern void AndroidReflection_IsAssignableFrom_m000432044555172C9399EB05A11AA35BFAF790FD (void);
// 0x0000002C System.IntPtr UnityEngine.AndroidReflection::GetStaticMethodID(System.String,System.String,System.String)
extern void AndroidReflection_GetStaticMethodID_m1D6770C9A0BC1AA47FDA330B92743324C0441B29 (void);
// 0x0000002D System.IntPtr UnityEngine.AndroidReflection::GetMethodID(System.String,System.String,System.String)
extern void AndroidReflection_GetMethodID_m504C04E3F1A9AD3C49260E03837DF2CDF88D35CF (void);
// 0x0000002E System.IntPtr UnityEngine.AndroidReflection::GetConstructorMember(System.IntPtr,System.String)
extern void AndroidReflection_GetConstructorMember_mE78FA3844BBB2FE5A6D3A6719BE72BD33423F4C9 (void);
// 0x0000002F System.IntPtr UnityEngine.AndroidReflection::GetMethodMember(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidReflection_GetMethodMember_m0B7C41F91CA0414D70EDFF7853BA93B11157EB19 (void);
// 0x00000030 System.IntPtr UnityEngine.AndroidReflection::NewProxyInstance(System.IntPtr,System.IntPtr)
extern void AndroidReflection_NewProxyInstance_mEE0634E1963302B17FBAED127B581BFE4D228A8C (void);
// 0x00000031 System.Void UnityEngine.AndroidReflection::SetNativeExceptionOnProxy(System.IntPtr,System.Exception,System.Boolean)
extern void AndroidReflection_SetNativeExceptionOnProxy_m025AFCDD8B6659D45FE3830E8AC154300DA19966 (void);
// 0x00000032 System.Void UnityEngine.AndroidReflection::.cctor()
extern void AndroidReflection__cctor_m328F9C260CA935498229C4D912C6B27618BEE8E6 (void);
// 0x00000033 System.IntPtr UnityEngine._AndroidJNIHelper::CreateJavaProxy(System.IntPtr,UnityEngine.AndroidJavaProxy)
extern void _AndroidJNIHelper_CreateJavaProxy_m8E6AAE823A5FB6D70B4655FA45203779946321ED (void);
// 0x00000034 System.IntPtr UnityEngine._AndroidJNIHelper::CreateJavaRunnable(UnityEngine.AndroidJavaRunnable)
extern void _AndroidJNIHelper_CreateJavaRunnable_mC009CB98AF579A1DBECE07EE23A4F20B8E53BDF0 (void);
// 0x00000035 System.IntPtr UnityEngine._AndroidJNIHelper::InvokeJavaProxyMethod(UnityEngine.AndroidJavaProxy,System.IntPtr,System.IntPtr)
extern void _AndroidJNIHelper_InvokeJavaProxyMethod_mF3275AFDFED43C42616A997FC582F1F90888AB87 (void);
// 0x00000036 UnityEngine.jvalue[] UnityEngine._AndroidJNIHelper::CreateJNIArgArray(System.Object[])
extern void _AndroidJNIHelper_CreateJNIArgArray_m9605B7C73D18B6A11264A61E33888374E1F283A9 (void);
// 0x00000037 System.Object UnityEngine._AndroidJNIHelper::UnboxArray(UnityEngine.AndroidJavaObject)
extern void _AndroidJNIHelper_UnboxArray_m57E035906F4D79FCAC155162AC491BB7B575956D (void);
// 0x00000038 System.Object UnityEngine._AndroidJNIHelper::Unbox(UnityEngine.AndroidJavaObject)
extern void _AndroidJNIHelper_Unbox_m813AFB8DE2C2568B011C81ED3AC4D013F1E5B67E (void);
// 0x00000039 UnityEngine.AndroidJavaObject UnityEngine._AndroidJNIHelper::Box(System.Object)
extern void _AndroidJNIHelper_Box_m67A2A786DCE5ADD2FAF4F27B7CA115C82A8768C2 (void);
// 0x0000003A System.Void UnityEngine._AndroidJNIHelper::DeleteJNIArgArray(System.Object[],UnityEngine.jvalue[])
extern void _AndroidJNIHelper_DeleteJNIArgArray_mCD37E30D32E979ED19131F9DC77A8DDD69D2E1A5 (void);
// 0x0000003B System.IntPtr UnityEngine._AndroidJNIHelper::ConvertToJNIArray(System.Array)
extern void _AndroidJNIHelper_ConvertToJNIArray_mBF20C1B6716BA00CA9C3825EA446B291E6D8EB20 (void);
// 0x0000003C ArrayType UnityEngine._AndroidJNIHelper::ConvertFromJNIArray(System.IntPtr)
// 0x0000003D System.IntPtr UnityEngine._AndroidJNIHelper::GetConstructorID(System.IntPtr,System.Object[])
extern void _AndroidJNIHelper_GetConstructorID_m1982E4290531BD8134C7B5EDF918B87466284D77 (void);
// 0x0000003E System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
// 0x0000003F System.IntPtr UnityEngine._AndroidJNIHelper::GetConstructorID(System.IntPtr,System.String)
extern void _AndroidJNIHelper_GetConstructorID_m9A5019D80C0E776003ADFC0A54A879ECDC3B60D8 (void);
// 0x00000040 System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.String,System.Boolean)
extern void _AndroidJNIHelper_GetMethodID_m22C073C0BCB560A1AD9EE6158FF8314D291EF756 (void);
// 0x00000041 System.IntPtr UnityEngine._AndroidJNIHelper::GetMethodIDFallback(System.IntPtr,System.String,System.String,System.Boolean)
extern void _AndroidJNIHelper_GetMethodIDFallback_m45AC36798A5258FE80A68A2453CE3C45792E2C95 (void);
// 0x00000042 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object)
extern void _AndroidJNIHelper_GetSignature_m090B053BFD9A6AC7BBD0F2BFAE56A8188CE4D80B (void);
// 0x00000043 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object[])
extern void _AndroidJNIHelper_GetSignature_m737340340A8C978F7AABB80DA4E31A8E700C73DA (void);
// 0x00000044 System.String UnityEngine._AndroidJNIHelper::GetSignature(System.Object[])
// 0x00000045 System.IntPtr UnityEngine.AndroidJNIHelper::GetConstructorID(System.IntPtr,System.String)
extern void AndroidJNIHelper_GetConstructorID_m9978ECF944003B11786DDB1FDF0456CD89AF1180 (void);
// 0x00000046 System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.String,System.Boolean)
extern void AndroidJNIHelper_GetMethodID_mD3057EDF00D6BBB3E89116EE05F68D0731AD9E43 (void);
// 0x00000047 System.IntPtr UnityEngine.AndroidJNIHelper::CreateJavaRunnable(UnityEngine.AndroidJavaRunnable)
extern void AndroidJNIHelper_CreateJavaRunnable_mA6C7A0E1BEF771970126D0FB21FF6E95CF569ED8 (void);
// 0x00000048 System.IntPtr UnityEngine.AndroidJNIHelper::CreateJavaProxy(UnityEngine.AndroidJavaProxy)
extern void AndroidJNIHelper_CreateJavaProxy_m29A8BD91809FF21642EA1319E5F097979EE8FA28 (void);
// 0x00000049 UnityEngine.jvalue[] UnityEngine.AndroidJNIHelper::CreateJNIArgArray(System.Object[])
extern void AndroidJNIHelper_CreateJNIArgArray_mAA5972FD580D58FA3D30B4E97B9837B439231F34 (void);
// 0x0000004A System.Void UnityEngine.AndroidJNIHelper::DeleteJNIArgArray(System.Object[],UnityEngine.jvalue[])
extern void AndroidJNIHelper_DeleteJNIArgArray_mEDFD8275CF10A3E0777350597633378776673784 (void);
// 0x0000004B System.IntPtr UnityEngine.AndroidJNIHelper::GetConstructorID(System.IntPtr,System.Object[])
extern void AndroidJNIHelper_GetConstructorID_m2756A393612A1CF86E3E73109E2268D9933F9F1E (void);
// 0x0000004C ArrayType UnityEngine.AndroidJNIHelper::ConvertFromJNIArray(System.IntPtr)
// 0x0000004D System.IntPtr UnityEngine.AndroidJNIHelper::GetMethodID(System.IntPtr,System.String,System.Object[],System.Boolean)
// 0x0000004E System.IntPtr UnityEngine.AndroidJNI::FindClass(System.String)
extern void AndroidJNI_FindClass_m07E2127D59F7EC97A06B5350699033448BD40CED (void);
// 0x0000004F System.IntPtr UnityEngine.AndroidJNI::FromReflectedMethod(System.IntPtr)
extern void AndroidJNI_FromReflectedMethod_m5F01D9D2E6FDB25E9DF3B8804FC6A536C71F84B9 (void);
// 0x00000050 System.IntPtr UnityEngine.AndroidJNI::ExceptionOccurred()
extern void AndroidJNI_ExceptionOccurred_mC2EC654C42E285C9E141393BDA41A4D8BC56FECD (void);
// 0x00000051 System.Void UnityEngine.AndroidJNI::ExceptionClear()
extern void AndroidJNI_ExceptionClear_m339CEFB228B0F08EBA289AED25464FF0D80B9936 (void);
// 0x00000052 System.IntPtr UnityEngine.AndroidJNI::NewGlobalRef(System.IntPtr)
extern void AndroidJNI_NewGlobalRef_m1F7D16F896A4153CC36ADBACFD740D6453E2AB54 (void);
// 0x00000053 System.Void UnityEngine.AndroidJNI::DeleteGlobalRef(System.IntPtr)
extern void AndroidJNI_DeleteGlobalRef_mC800FCE93424A8778220806C3FE3497E21E94333 (void);
// 0x00000054 System.IntPtr UnityEngine.AndroidJNI::NewWeakGlobalRef(System.IntPtr)
extern void AndroidJNI_NewWeakGlobalRef_m907BCFA1475E108FBBD02A8A425929EC859D0E8C (void);
// 0x00000055 System.Void UnityEngine.AndroidJNI::DeleteWeakGlobalRef(System.IntPtr)
extern void AndroidJNI_DeleteWeakGlobalRef_m07AE954A94CDB58980A3CBA36E0E8F236BE01C75 (void);
// 0x00000056 System.IntPtr UnityEngine.AndroidJNI::NewLocalRef(System.IntPtr)
extern void AndroidJNI_NewLocalRef_m22674FDA13C73173E0ECB3F59DE15CBDAD4CD039 (void);
// 0x00000057 System.Void UnityEngine.AndroidJNI::DeleteLocalRef(System.IntPtr)
extern void AndroidJNI_DeleteLocalRef_m5A7291640D0BB0F2A484C729CEDBF43F92B7941A (void);
// 0x00000058 System.IntPtr UnityEngine.AndroidJNI::NewObject(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_NewObject_mA1E19D3C530766C0E9F3196CB23A4C9E7795689B (void);
// 0x00000059 System.IntPtr UnityEngine.AndroidJNI::GetObjectClass(System.IntPtr)
extern void AndroidJNI_GetObjectClass_mA9719B0A6734C4ED55B60B129A9D51F7B8A3B4A6 (void);
// 0x0000005A System.IntPtr UnityEngine.AndroidJNI::GetMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetMethodID_m4D7386D69FFEF80467F1804447C094B59385AF0C (void);
// 0x0000005B System.IntPtr UnityEngine.AndroidJNI::GetStaticMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNI_GetStaticMethodID_m135C9DEFFC207E509C001370C227F6E217FD9A1C (void);
// 0x0000005C System.IntPtr UnityEngine.AndroidJNI::NewString(System.String)
extern void AndroidJNI_NewString_m4B505016C60A4B2602F2037983367C2DB52A8BE2 (void);
// 0x0000005D System.IntPtr UnityEngine.AndroidJNI::NewStringFromStr(System.String)
extern void AndroidJNI_NewStringFromStr_m01AAA91EC40C908302162C5653D6AFEFC384BBA9 (void);
// 0x0000005E System.String UnityEngine.AndroidJNI::GetStringChars(System.IntPtr)
extern void AndroidJNI_GetStringChars_m1C44DAAF9B7AA8E9586F1CD236E825B07741A268 (void);
// 0x0000005F System.String UnityEngine.AndroidJNI::CallStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStringMethod_m3322E22FCA053618D794A9F3D00CFA1368F10AA9 (void);
// 0x00000060 System.IntPtr UnityEngine.AndroidJNI::CallObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallObjectMethod_m953C16AD55D061D331B16060D9C2E7BEFFC34BB0 (void);
// 0x00000061 System.Int32 UnityEngine.AndroidJNI::CallIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallIntMethod_m83AA9264B8978F8D42B4B5239CEDA616AD6FE047 (void);
// 0x00000062 System.Boolean UnityEngine.AndroidJNI::CallBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallBooleanMethod_mAE45802EE32D57194B47BC62E0AD9F8C56C41800 (void);
// 0x00000063 System.Int16 UnityEngine.AndroidJNI::CallShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallShortMethod_m1402B57DDA2B128398A7A911CDB24E06ED376D51 (void);
// 0x00000064 System.SByte UnityEngine.AndroidJNI::CallSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallSByteMethod_m34A084018795E6E5847305390565A2A494AD2422 (void);
// 0x00000065 System.Char UnityEngine.AndroidJNI::CallCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallCharMethod_mC5FEB28906B1F004D5EAE36363C2F2B32B4D25FD (void);
// 0x00000066 System.Single UnityEngine.AndroidJNI::CallFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallFloatMethod_mFDB1FC58B999500B822E336ABB60408463FD9BAF (void);
// 0x00000067 System.Double UnityEngine.AndroidJNI::CallDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallDoubleMethod_m391E75D42B6B445B80D751F56440DDE1C20A79EE (void);
// 0x00000068 System.Int64 UnityEngine.AndroidJNI::CallLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallLongMethod_mF2B511CFE25949D688142C6A8A11973C22BE1AFC (void);
// 0x00000069 System.String UnityEngine.AndroidJNI::CallStaticStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticStringMethod_m7502E60348B62159AE2F0C06D3D663E6E1F28116 (void);
// 0x0000006A System.IntPtr UnityEngine.AndroidJNI::CallStaticObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticObjectMethod_m8540B678387A3DE6F1F702CF3053826962F569C0 (void);
// 0x0000006B System.Int32 UnityEngine.AndroidJNI::CallStaticIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticIntMethod_mC112D86B8844819C4D02AA8136BCF8C673B59FF0 (void);
// 0x0000006C System.Boolean UnityEngine.AndroidJNI::CallStaticBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticBooleanMethod_mA5C4F5D3A724351C0DB569E863F070493E86069F (void);
// 0x0000006D System.Int16 UnityEngine.AndroidJNI::CallStaticShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticShortMethod_m1BC0BA260F59800529D511D0E51B501165056F3F (void);
// 0x0000006E System.SByte UnityEngine.AndroidJNI::CallStaticSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticSByteMethod_m637357610E5ECF91256FD6EFA48468D276395F46 (void);
// 0x0000006F System.Char UnityEngine.AndroidJNI::CallStaticCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticCharMethod_m03968EDD820122C5AA74D396578D5C8F747DE8B9 (void);
// 0x00000070 System.Single UnityEngine.AndroidJNI::CallStaticFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticFloatMethod_m22FE454F030F117CFA7CE8F8CE55A4DD9EB226DD (void);
// 0x00000071 System.Double UnityEngine.AndroidJNI::CallStaticDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticDoubleMethod_mB27665BD677D31470812D5E4FA466259D18D8D67 (void);
// 0x00000072 System.Int64 UnityEngine.AndroidJNI::CallStaticLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticLongMethod_mACA1CFC943C54BB656D065AB6EF0A78FE3EEC014 (void);
// 0x00000073 System.Void UnityEngine.AndroidJNI::CallStaticVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNI_CallStaticVoidMethod_m973B08F0CE8068F0AC8A8FF85F0C63FD5AC3EAFA (void);
// 0x00000074 System.IntPtr UnityEngine.AndroidJNI::ToBooleanArray(System.Boolean[])
extern void AndroidJNI_ToBooleanArray_m7BEE0A1FEC1AAB4A244716CD93ABB456DC8E28C2 (void);
// 0x00000075 System.IntPtr UnityEngine.AndroidJNI::ToByteArray(System.Byte[])
extern void AndroidJNI_ToByteArray_m57A1B1DD05FCA40796E0CFAA8297528E807CB5F4 (void);
// 0x00000076 System.IntPtr UnityEngine.AndroidJNI::ToSByteArray(System.SByte[])
extern void AndroidJNI_ToSByteArray_mB78915C5C2948F80376765449650782802E03707 (void);
// 0x00000077 System.IntPtr UnityEngine.AndroidJNI::ToCharArray(System.Char[])
extern void AndroidJNI_ToCharArray_m2052C19FC000D01BA74DDAA7AC5EF8D4D13D1F6A (void);
// 0x00000078 System.IntPtr UnityEngine.AndroidJNI::ToShortArray(System.Int16[])
extern void AndroidJNI_ToShortArray_m7FCED435AE3ACC7808F3CB9F9C5E8E16B616A316 (void);
// 0x00000079 System.IntPtr UnityEngine.AndroidJNI::ToIntArray(System.Int32[])
extern void AndroidJNI_ToIntArray_mB69CEC2992884ADC394A9A7E604967B7B57651A9 (void);
// 0x0000007A System.IntPtr UnityEngine.AndroidJNI::ToLongArray(System.Int64[])
extern void AndroidJNI_ToLongArray_mFAAAB30B9A9944A7D6A590ADE0ACB50A11656928 (void);
// 0x0000007B System.IntPtr UnityEngine.AndroidJNI::ToFloatArray(System.Single[])
extern void AndroidJNI_ToFloatArray_m684CAD369A3BDCE75B31FCC68F8CF7A1293A4533 (void);
// 0x0000007C System.IntPtr UnityEngine.AndroidJNI::ToDoubleArray(System.Double[])
extern void AndroidJNI_ToDoubleArray_mB04386ABEC07D54732102A858B7F5250B49601CE (void);
// 0x0000007D System.IntPtr UnityEngine.AndroidJNI::ToObjectArray(System.IntPtr[],System.IntPtr)
extern void AndroidJNI_ToObjectArray_m0614CB442A041E1EE108ADF05676C001710EC33A (void);
// 0x0000007E System.Boolean[] UnityEngine.AndroidJNI::FromBooleanArray(System.IntPtr)
extern void AndroidJNI_FromBooleanArray_mA5AF86E8FDA0D4B7CCA395E708527E2A1073AA86 (void);
// 0x0000007F System.Byte[] UnityEngine.AndroidJNI::FromByteArray(System.IntPtr)
extern void AndroidJNI_FromByteArray_mB1B0AC781BA50C8AE7F9A6B8660B7C3F6D7DDE02 (void);
// 0x00000080 System.SByte[] UnityEngine.AndroidJNI::FromSByteArray(System.IntPtr)
extern void AndroidJNI_FromSByteArray_m15A1A9366FC6A1952DA42809D8EEF59678ABF69E (void);
// 0x00000081 System.Char[] UnityEngine.AndroidJNI::FromCharArray(System.IntPtr)
extern void AndroidJNI_FromCharArray_mB24FA47F69D0B382F0D3F5F4B62F9B6F14F52842 (void);
// 0x00000082 System.Int16[] UnityEngine.AndroidJNI::FromShortArray(System.IntPtr)
extern void AndroidJNI_FromShortArray_m1084FF60F463C8EB3890406EEDBB9F1DFC80116B (void);
// 0x00000083 System.Int32[] UnityEngine.AndroidJNI::FromIntArray(System.IntPtr)
extern void AndroidJNI_FromIntArray_mD538A30307431BC4BEC75F3709701742131FE6F8 (void);
// 0x00000084 System.Int64[] UnityEngine.AndroidJNI::FromLongArray(System.IntPtr)
extern void AndroidJNI_FromLongArray_m5EDB9FD73EBB1F49486524B6A62B644D171A3CA4 (void);
// 0x00000085 System.Single[] UnityEngine.AndroidJNI::FromFloatArray(System.IntPtr)
extern void AndroidJNI_FromFloatArray_m5B41CA3BE4AAB40310042C0CFA624BFDBF1E15CB (void);
// 0x00000086 System.Double[] UnityEngine.AndroidJNI::FromDoubleArray(System.IntPtr)
extern void AndroidJNI_FromDoubleArray_m0994CF71AF7314249C12F3070FC50E048446D63E (void);
// 0x00000087 System.Int32 UnityEngine.AndroidJNI::GetArrayLength(System.IntPtr)
extern void AndroidJNI_GetArrayLength_m3DD9BD96B89F86A4F8AAB10147CAADB951E49936 (void);
// 0x00000088 System.IntPtr UnityEngine.AndroidJNI::NewObjectArray(System.Int32,System.IntPtr,System.IntPtr)
extern void AndroidJNI_NewObjectArray_m49BBDBCC804A6799866B92D6E0DEA9A204B6BE43 (void);
// 0x00000089 System.IntPtr UnityEngine.AndroidJNI::GetObjectArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNI_GetObjectArrayElement_m104E43629B8731ACAF53A5D351CCB19398A75648 (void);
// 0x0000008A System.Void UnityEngine.AndroidJNI::SetObjectArrayElement(System.IntPtr,System.Int32,System.IntPtr)
extern void AndroidJNI_SetObjectArrayElement_m3CB77880BEEAA75E69813F5B193F07BDD8933418 (void);
// 0x0000008B System.Void UnityEngine.AndroidJNISafe::CheckException()
extern void AndroidJNISafe_CheckException_m39B8553ABAD4AFD5D34089327D3179870E168B9C (void);
// 0x0000008C System.Void UnityEngine.AndroidJNISafe::DeleteGlobalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteGlobalRef_mE0C851F30E3481496C72814973B66161C486D8BA (void);
// 0x0000008D System.Void UnityEngine.AndroidJNISafe::DeleteWeakGlobalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteWeakGlobalRef_mB338C2F7116360905B7F444BDB16CAB18B914ED3 (void);
// 0x0000008E System.Void UnityEngine.AndroidJNISafe::DeleteLocalRef(System.IntPtr)
extern void AndroidJNISafe_DeleteLocalRef_m9632EA13BF03AEE43FC7713125962A4D0DFFADC7 (void);
// 0x0000008F System.IntPtr UnityEngine.AndroidJNISafe::NewString(System.String)
extern void AndroidJNISafe_NewString_mD1D954E0EE5A8F135B19EE67E8FF2A4E1A6CA97F (void);
// 0x00000090 System.String UnityEngine.AndroidJNISafe::GetStringChars(System.IntPtr)
extern void AndroidJNISafe_GetStringChars_m15C4A04998812B41DF6E67D7D2F9F270573847FE (void);
// 0x00000091 System.IntPtr UnityEngine.AndroidJNISafe::GetObjectClass(System.IntPtr)
extern void AndroidJNISafe_GetObjectClass_mB36866622A9FD487DCA6926F63038E5584B35BFB (void);
// 0x00000092 System.IntPtr UnityEngine.AndroidJNISafe::GetStaticMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetStaticMethodID_m4DCBC629048509F8E8566998CDA8F1AB9EAD6A50 (void);
// 0x00000093 System.IntPtr UnityEngine.AndroidJNISafe::GetMethodID(System.IntPtr,System.String,System.String)
extern void AndroidJNISafe_GetMethodID_m91CE11744503D04CD2AA8BAD99C914B1C2C6D494 (void);
// 0x00000094 System.IntPtr UnityEngine.AndroidJNISafe::FromReflectedMethod(System.IntPtr)
extern void AndroidJNISafe_FromReflectedMethod_m47AA20F4A2F8451B9BDCF8C6045802F04112F221 (void);
// 0x00000095 System.IntPtr UnityEngine.AndroidJNISafe::FindClass(System.String)
extern void AndroidJNISafe_FindClass_mE58501828AA09ADC26347853AFE6D025845D487C (void);
// 0x00000096 System.IntPtr UnityEngine.AndroidJNISafe::NewObject(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_NewObject_m78BDA85E651167163148C9B39DEA8CE831EB1DB0 (void);
// 0x00000097 System.Void UnityEngine.AndroidJNISafe::CallStaticVoidMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticVoidMethod_mC0BC9FA7E2FB69027E1F55E8810C6F619BCD7D59 (void);
// 0x00000098 System.IntPtr UnityEngine.AndroidJNISafe::CallStaticObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticObjectMethod_m11EDE005224D5A6833BFF896906397D24E19D440 (void);
// 0x00000099 System.String UnityEngine.AndroidJNISafe::CallStaticStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticStringMethod_mBB43D0D0B7D7ED48C90F9D9FF583A629DC40EBA3 (void);
// 0x0000009A System.Char UnityEngine.AndroidJNISafe::CallStaticCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticCharMethod_mC422B2FB9D7F13C0BEC8DAF00119B82FEA2854D9 (void);
// 0x0000009B System.Double UnityEngine.AndroidJNISafe::CallStaticDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticDoubleMethod_mC5A3C5AEEC15EB5D419E7B2B0A45DE2762310ABE (void);
// 0x0000009C System.Single UnityEngine.AndroidJNISafe::CallStaticFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticFloatMethod_mA0AEAAA5ACCC7EB36F04616DCB2E09D29B6DED30 (void);
// 0x0000009D System.Int64 UnityEngine.AndroidJNISafe::CallStaticLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticLongMethod_mDEA9005EBB9126BD13C56C1D4497C60863F1D00B (void);
// 0x0000009E System.Int16 UnityEngine.AndroidJNISafe::CallStaticShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticShortMethod_m970528ACEB23F9AE4A38A9B223B825DF10A64F09 (void);
// 0x0000009F System.SByte UnityEngine.AndroidJNISafe::CallStaticSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticSByteMethod_m6F9A948F2EE6B668618D1B39FF3450368FA95010 (void);
// 0x000000A0 System.Boolean UnityEngine.AndroidJNISafe::CallStaticBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticBooleanMethod_mD4AE550694EEC7859F137D0C60F0C94BD1092272 (void);
// 0x000000A1 System.Int32 UnityEngine.AndroidJNISafe::CallStaticIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStaticIntMethod_mBBD8501C4128A05B243DEDD7FC1473B7F8B6DFCA (void);
// 0x000000A2 System.IntPtr UnityEngine.AndroidJNISafe::CallObjectMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallObjectMethod_m4E9B0BCDACAF851BA170F85BA9F06727B6A3452B (void);
// 0x000000A3 System.String UnityEngine.AndroidJNISafe::CallStringMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallStringMethod_mF74DF782A0F41B0355910B4A6D1A88FFCA9E767D (void);
// 0x000000A4 System.Char UnityEngine.AndroidJNISafe::CallCharMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallCharMethod_mCE65F1C456B282169DFCD5A7D87E4DF78EE89626 (void);
// 0x000000A5 System.Double UnityEngine.AndroidJNISafe::CallDoubleMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallDoubleMethod_m47F889A5E70637CDF523C7A84CC7F657FBEB8427 (void);
// 0x000000A6 System.Single UnityEngine.AndroidJNISafe::CallFloatMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallFloatMethod_m74F15E4AE8B0341919AD470E0528599F3042E0D5 (void);
// 0x000000A7 System.Int64 UnityEngine.AndroidJNISafe::CallLongMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallLongMethod_m30E44F8538D228134490B925FF35A2E8D194D0FC (void);
// 0x000000A8 System.Int16 UnityEngine.AndroidJNISafe::CallShortMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallShortMethod_m0922D537A7A7C7576BA5CFA7359EEB1430B142B8 (void);
// 0x000000A9 System.SByte UnityEngine.AndroidJNISafe::CallSByteMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallSByteMethod_mBC18848E620817FD4BCD72EB66E5EFDE64B34AA8 (void);
// 0x000000AA System.Boolean UnityEngine.AndroidJNISafe::CallBooleanMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallBooleanMethod_mE15E3147C3BD2BE20EE4ACD537DFB1253254E743 (void);
// 0x000000AB System.Int32 UnityEngine.AndroidJNISafe::CallIntMethod(System.IntPtr,System.IntPtr,UnityEngine.jvalue[])
extern void AndroidJNISafe_CallIntMethod_m014D37C85659EDCDDFF9A4007ED1943981525E95 (void);
// 0x000000AC System.Char[] UnityEngine.AndroidJNISafe::FromCharArray(System.IntPtr)
extern void AndroidJNISafe_FromCharArray_mDB6AE528FE52AC622EB833337F36AA93B5248E1B (void);
// 0x000000AD System.Double[] UnityEngine.AndroidJNISafe::FromDoubleArray(System.IntPtr)
extern void AndroidJNISafe_FromDoubleArray_m10BE0E812ED3FC49D0FF7EFA7352F8EA026F824E (void);
// 0x000000AE System.Single[] UnityEngine.AndroidJNISafe::FromFloatArray(System.IntPtr)
extern void AndroidJNISafe_FromFloatArray_m087EAD07306786A03F15756F9EC26CA2AB6B8BCB (void);
// 0x000000AF System.Int64[] UnityEngine.AndroidJNISafe::FromLongArray(System.IntPtr)
extern void AndroidJNISafe_FromLongArray_mDCCAE11E1BB9C72B1DCB0D5CB4D191922EB499C5 (void);
// 0x000000B0 System.Int16[] UnityEngine.AndroidJNISafe::FromShortArray(System.IntPtr)
extern void AndroidJNISafe_FromShortArray_m05B4445B460FC16B41851A5C898123223C0B0024 (void);
// 0x000000B1 System.Byte[] UnityEngine.AndroidJNISafe::FromByteArray(System.IntPtr)
extern void AndroidJNISafe_FromByteArray_m8182D68596E21605519D27197C4870DCAB9F6550 (void);
// 0x000000B2 System.SByte[] UnityEngine.AndroidJNISafe::FromSByteArray(System.IntPtr)
extern void AndroidJNISafe_FromSByteArray_m44649611607069754D9DD6A53B58C65AAE69C8E8 (void);
// 0x000000B3 System.Boolean[] UnityEngine.AndroidJNISafe::FromBooleanArray(System.IntPtr)
extern void AndroidJNISafe_FromBooleanArray_m4CA0BE409AC39C391C4122A1DCE503B7EA87DC14 (void);
// 0x000000B4 System.Int32[] UnityEngine.AndroidJNISafe::FromIntArray(System.IntPtr)
extern void AndroidJNISafe_FromIntArray_m5AB9419F8E92A4815A833006025ABD0039D6B353 (void);
// 0x000000B5 System.IntPtr UnityEngine.AndroidJNISafe::ToObjectArray(System.IntPtr[],System.IntPtr)
extern void AndroidJNISafe_ToObjectArray_mB3A0EB74E8C47EB72667603D90A4DE2480E2AC63 (void);
// 0x000000B6 System.IntPtr UnityEngine.AndroidJNISafe::ToCharArray(System.Char[])
extern void AndroidJNISafe_ToCharArray_m8AB18ECC188D1B8A15966FF3FBD7887CF35A5711 (void);
// 0x000000B7 System.IntPtr UnityEngine.AndroidJNISafe::ToDoubleArray(System.Double[])
extern void AndroidJNISafe_ToDoubleArray_m9AE319DB92B91A255D2A0568D38B3B47CD0C69EB (void);
// 0x000000B8 System.IntPtr UnityEngine.AndroidJNISafe::ToFloatArray(System.Single[])
extern void AndroidJNISafe_ToFloatArray_m8ACA5E42C6F32E7D851613AC129FB37AFC28EBFD (void);
// 0x000000B9 System.IntPtr UnityEngine.AndroidJNISafe::ToLongArray(System.Int64[])
extern void AndroidJNISafe_ToLongArray_mD59D9304170DFB59B77342C994699BE445AF25D3 (void);
// 0x000000BA System.IntPtr UnityEngine.AndroidJNISafe::ToShortArray(System.Int16[])
extern void AndroidJNISafe_ToShortArray_m7D79F918714300B5818C7C8646E4E1A48E056A07 (void);
// 0x000000BB System.IntPtr UnityEngine.AndroidJNISafe::ToByteArray(System.Byte[])
extern void AndroidJNISafe_ToByteArray_m01C86D2FE9259F0888FA97B105FC741A0E2290D5 (void);
// 0x000000BC System.IntPtr UnityEngine.AndroidJNISafe::ToSByteArray(System.SByte[])
extern void AndroidJNISafe_ToSByteArray_m5AE0F49EE17ABDCFBCDF619CBECD5DEF9961BDB8 (void);
// 0x000000BD System.IntPtr UnityEngine.AndroidJNISafe::ToBooleanArray(System.Boolean[])
extern void AndroidJNISafe_ToBooleanArray_m1BCBD2041B6BFE6B91C1E3AD8C1133F791B70423 (void);
// 0x000000BE System.IntPtr UnityEngine.AndroidJNISafe::ToIntArray(System.Int32[])
extern void AndroidJNISafe_ToIntArray_m324EDE9CCF1C9909444C40617BD3358172EFB874 (void);
// 0x000000BF System.IntPtr UnityEngine.AndroidJNISafe::GetObjectArrayElement(System.IntPtr,System.Int32)
extern void AndroidJNISafe_GetObjectArrayElement_mA87BFEFBCE1C7D1B5B817CCCB5D4B7F009FD37BD (void);
// 0x000000C0 System.Int32 UnityEngine.AndroidJNISafe::GetArrayLength(System.IntPtr)
extern void AndroidJNISafe_GetArrayLength_m11614663772194842C0D75FB8C6FBDB92F8DEE05 (void);
static Il2CppMethodPointer s_methodPointers[192] = 
{
	AndroidJavaRunnable__ctor_mF5ED3CD9300D6D702748378A0E0633612866D052,
	AndroidJavaRunnable_Invoke_m98A444239D449E61110C80E5F18D3C1D386FE79B,
	AndroidJavaRunnable_BeginInvoke_mC020AAC7B0B350E65DDA128222B54D5B10FE43ED,
	AndroidJavaRunnable_EndInvoke_m4301C1FBD81C209F7056166325A35617DD10B5E9,
	AndroidJavaException__ctor_m8E5216F0181090FB7A9016AED78B7935019791D8,
	AndroidJavaException_get_StackTrace_m0CBD35F72DF136212F27E63C3BAF4FB7D956C710,
	GlobalJavaObjectRef__ctor_m5581A68DC5217545E13F48ACF2DAFD9DF30396BC,
	GlobalJavaObjectRef_Finalize_mAC26B588678FAB49013BFD07E5090E438E016F83,
	GlobalJavaObjectRef_op_Implicit_m1F52DE72C8F8B11E651F8B31879ED5AFD413EDFF,
	GlobalJavaObjectRef_Dispose_mDCFD34D040E7B4ACE886336F3659316D1A45599F,
	AndroidJavaRunnableProxy__ctor_m0D23BFCE5D99EA0AA56A5813B2E91BDDAD72C738,
	AndroidJavaProxy__ctor_m159565DEF4041D92C0763D1F4A0684140241CD9A,
	AndroidJavaProxy__ctor_m9A2D1F4BF0E7803070D68D3C386F4218D3BCAC0F,
	AndroidJavaProxy_Finalize_mB53473746276958436FE45332CD82C6847F14D73,
	AndroidJavaProxy_Invoke_m2A4BA59C6A517E0B692478676AA0A0A77980848E,
	AndroidJavaProxy_Invoke_m27ACB084BB434FFEA8A1FB687CCB332F4EB80B9B,
	AndroidJavaProxy_GetProxyObject_m411DC59BF56152B6058ABF99BBC8B64C813EEF06,
	AndroidJavaProxy_GetRawProxy_mFE7D48E72D4744E260D3ACE6D777D072002BEA6C,
	AndroidJavaProxy__cctor_mC5B6251AA25617F7CE1AD4DAD0BD2CCAC9636C9F,
	AndroidJavaObject__ctor_m39462EAD9AD82CBD90DEB4B7127F3D6C87A02BFA,
	AndroidJavaObject_Dispose_m02D1B6D8F3E902E5F0D181BF6C1753856B0DE144,
	AndroidJavaObject_GetRawObject_mCEB7EEC51D62A3E4F0D6F62C08CBEF008B556F3D,
	AndroidJavaObject_GetRawClass_m28BFE7AD6A4FFCB45929D9D1A0F8D792C3974774,
	NULL,
	NULL,
	AndroidJavaObject_DebugPrint_m88F06202527BA5A2848C1533C8B396702D112531,
	AndroidJavaObject__AndroidJavaObject_m596F928EE49384D7C7455920BA6ADFB2D9540CFA,
	AndroidJavaObject__ctor_m22E1E2E5D9F3DA31FF7DFB1339AD3BB0C3813E80,
	AndroidJavaObject__ctor_m4C0CDAB96B807BB04E2C43609F16865034A60001,
	AndroidJavaObject_Finalize_m834AA4594A7070A6DE1CA884752D2928ACAF2AF0,
	AndroidJavaObject_Dispose_m5F40DCA32137A2280BE224A63A89B8FE637619DA,
	NULL,
	NULL,
	AndroidJavaObject_AndroidJavaObjectDeleteLocalRef_m0B0BCBDD56C299AC69938BDD4135E1B6EEAAC7EF,
	AndroidJavaObject_AndroidJavaClassDeleteLocalRef_mD137411129D4E0B5AB858EAE367EBBA0E668D962,
	AndroidJavaObject__GetRawObject_m4B415E770E265AE32F5523DF0E627626F77E572F,
	AndroidJavaObject__GetRawClass_m1B3729CDBBC212E0C706256FF16D2F437F618435,
	AndroidJavaObject__cctor_m46EF3B9E61C141E07E12762F96F777EA8D1A4629,
	AndroidJavaClass__ctor_mAE416E812DB3911279C0FE87A7760247CE1BBFA8,
	AndroidJavaClass__AndroidJavaClass_mBF3C92E82722125793A66F20C92BAE17F0CB02D9,
	AndroidJavaClass__ctor_m44A6DEC0612D768E9947FFC1C2DA64D0605F34F1,
	AndroidReflection_IsPrimitive_m4C75B1AAEDD3FA0F73AFBC83CB374D3D8A9A3749,
	AndroidReflection_IsAssignableFrom_m000432044555172C9399EB05A11AA35BFAF790FD,
	AndroidReflection_GetStaticMethodID_m1D6770C9A0BC1AA47FDA330B92743324C0441B29,
	AndroidReflection_GetMethodID_m504C04E3F1A9AD3C49260E03837DF2CDF88D35CF,
	AndroidReflection_GetConstructorMember_mE78FA3844BBB2FE5A6D3A6719BE72BD33423F4C9,
	AndroidReflection_GetMethodMember_m0B7C41F91CA0414D70EDFF7853BA93B11157EB19,
	AndroidReflection_NewProxyInstance_mEE0634E1963302B17FBAED127B581BFE4D228A8C,
	AndroidReflection_SetNativeExceptionOnProxy_m025AFCDD8B6659D45FE3830E8AC154300DA19966,
	AndroidReflection__cctor_m328F9C260CA935498229C4D912C6B27618BEE8E6,
	_AndroidJNIHelper_CreateJavaProxy_m8E6AAE823A5FB6D70B4655FA45203779946321ED,
	_AndroidJNIHelper_CreateJavaRunnable_mC009CB98AF579A1DBECE07EE23A4F20B8E53BDF0,
	_AndroidJNIHelper_InvokeJavaProxyMethod_mF3275AFDFED43C42616A997FC582F1F90888AB87,
	_AndroidJNIHelper_CreateJNIArgArray_m9605B7C73D18B6A11264A61E33888374E1F283A9,
	_AndroidJNIHelper_UnboxArray_m57E035906F4D79FCAC155162AC491BB7B575956D,
	_AndroidJNIHelper_Unbox_m813AFB8DE2C2568B011C81ED3AC4D013F1E5B67E,
	_AndroidJNIHelper_Box_m67A2A786DCE5ADD2FAF4F27B7CA115C82A8768C2,
	_AndroidJNIHelper_DeleteJNIArgArray_mCD37E30D32E979ED19131F9DC77A8DDD69D2E1A5,
	_AndroidJNIHelper_ConvertToJNIArray_mBF20C1B6716BA00CA9C3825EA446B291E6D8EB20,
	NULL,
	_AndroidJNIHelper_GetConstructorID_m1982E4290531BD8134C7B5EDF918B87466284D77,
	NULL,
	_AndroidJNIHelper_GetConstructorID_m9A5019D80C0E776003ADFC0A54A879ECDC3B60D8,
	_AndroidJNIHelper_GetMethodID_m22C073C0BCB560A1AD9EE6158FF8314D291EF756,
	_AndroidJNIHelper_GetMethodIDFallback_m45AC36798A5258FE80A68A2453CE3C45792E2C95,
	_AndroidJNIHelper_GetSignature_m090B053BFD9A6AC7BBD0F2BFAE56A8188CE4D80B,
	_AndroidJNIHelper_GetSignature_m737340340A8C978F7AABB80DA4E31A8E700C73DA,
	NULL,
	AndroidJNIHelper_GetConstructorID_m9978ECF944003B11786DDB1FDF0456CD89AF1180,
	AndroidJNIHelper_GetMethodID_mD3057EDF00D6BBB3E89116EE05F68D0731AD9E43,
	AndroidJNIHelper_CreateJavaRunnable_mA6C7A0E1BEF771970126D0FB21FF6E95CF569ED8,
	AndroidJNIHelper_CreateJavaProxy_m29A8BD91809FF21642EA1319E5F097979EE8FA28,
	AndroidJNIHelper_CreateJNIArgArray_mAA5972FD580D58FA3D30B4E97B9837B439231F34,
	AndroidJNIHelper_DeleteJNIArgArray_mEDFD8275CF10A3E0777350597633378776673784,
	AndroidJNIHelper_GetConstructorID_m2756A393612A1CF86E3E73109E2268D9933F9F1E,
	NULL,
	NULL,
	AndroidJNI_FindClass_m07E2127D59F7EC97A06B5350699033448BD40CED,
	AndroidJNI_FromReflectedMethod_m5F01D9D2E6FDB25E9DF3B8804FC6A536C71F84B9,
	AndroidJNI_ExceptionOccurred_mC2EC654C42E285C9E141393BDA41A4D8BC56FECD,
	AndroidJNI_ExceptionClear_m339CEFB228B0F08EBA289AED25464FF0D80B9936,
	AndroidJNI_NewGlobalRef_m1F7D16F896A4153CC36ADBACFD740D6453E2AB54,
	AndroidJNI_DeleteGlobalRef_mC800FCE93424A8778220806C3FE3497E21E94333,
	AndroidJNI_NewWeakGlobalRef_m907BCFA1475E108FBBD02A8A425929EC859D0E8C,
	AndroidJNI_DeleteWeakGlobalRef_m07AE954A94CDB58980A3CBA36E0E8F236BE01C75,
	AndroidJNI_NewLocalRef_m22674FDA13C73173E0ECB3F59DE15CBDAD4CD039,
	AndroidJNI_DeleteLocalRef_m5A7291640D0BB0F2A484C729CEDBF43F92B7941A,
	AndroidJNI_NewObject_mA1E19D3C530766C0E9F3196CB23A4C9E7795689B,
	AndroidJNI_GetObjectClass_mA9719B0A6734C4ED55B60B129A9D51F7B8A3B4A6,
	AndroidJNI_GetMethodID_m4D7386D69FFEF80467F1804447C094B59385AF0C,
	AndroidJNI_GetStaticMethodID_m135C9DEFFC207E509C001370C227F6E217FD9A1C,
	AndroidJNI_NewString_m4B505016C60A4B2602F2037983367C2DB52A8BE2,
	AndroidJNI_NewStringFromStr_m01AAA91EC40C908302162C5653D6AFEFC384BBA9,
	AndroidJNI_GetStringChars_m1C44DAAF9B7AA8E9586F1CD236E825B07741A268,
	AndroidJNI_CallStringMethod_m3322E22FCA053618D794A9F3D00CFA1368F10AA9,
	AndroidJNI_CallObjectMethod_m953C16AD55D061D331B16060D9C2E7BEFFC34BB0,
	AndroidJNI_CallIntMethod_m83AA9264B8978F8D42B4B5239CEDA616AD6FE047,
	AndroidJNI_CallBooleanMethod_mAE45802EE32D57194B47BC62E0AD9F8C56C41800,
	AndroidJNI_CallShortMethod_m1402B57DDA2B128398A7A911CDB24E06ED376D51,
	AndroidJNI_CallSByteMethod_m34A084018795E6E5847305390565A2A494AD2422,
	AndroidJNI_CallCharMethod_mC5FEB28906B1F004D5EAE36363C2F2B32B4D25FD,
	AndroidJNI_CallFloatMethod_mFDB1FC58B999500B822E336ABB60408463FD9BAF,
	AndroidJNI_CallDoubleMethod_m391E75D42B6B445B80D751F56440DDE1C20A79EE,
	AndroidJNI_CallLongMethod_mF2B511CFE25949D688142C6A8A11973C22BE1AFC,
	AndroidJNI_CallStaticStringMethod_m7502E60348B62159AE2F0C06D3D663E6E1F28116,
	AndroidJNI_CallStaticObjectMethod_m8540B678387A3DE6F1F702CF3053826962F569C0,
	AndroidJNI_CallStaticIntMethod_mC112D86B8844819C4D02AA8136BCF8C673B59FF0,
	AndroidJNI_CallStaticBooleanMethod_mA5C4F5D3A724351C0DB569E863F070493E86069F,
	AndroidJNI_CallStaticShortMethod_m1BC0BA260F59800529D511D0E51B501165056F3F,
	AndroidJNI_CallStaticSByteMethod_m637357610E5ECF91256FD6EFA48468D276395F46,
	AndroidJNI_CallStaticCharMethod_m03968EDD820122C5AA74D396578D5C8F747DE8B9,
	AndroidJNI_CallStaticFloatMethod_m22FE454F030F117CFA7CE8F8CE55A4DD9EB226DD,
	AndroidJNI_CallStaticDoubleMethod_mB27665BD677D31470812D5E4FA466259D18D8D67,
	AndroidJNI_CallStaticLongMethod_mACA1CFC943C54BB656D065AB6EF0A78FE3EEC014,
	AndroidJNI_CallStaticVoidMethod_m973B08F0CE8068F0AC8A8FF85F0C63FD5AC3EAFA,
	AndroidJNI_ToBooleanArray_m7BEE0A1FEC1AAB4A244716CD93ABB456DC8E28C2,
	AndroidJNI_ToByteArray_m57A1B1DD05FCA40796E0CFAA8297528E807CB5F4,
	AndroidJNI_ToSByteArray_mB78915C5C2948F80376765449650782802E03707,
	AndroidJNI_ToCharArray_m2052C19FC000D01BA74DDAA7AC5EF8D4D13D1F6A,
	AndroidJNI_ToShortArray_m7FCED435AE3ACC7808F3CB9F9C5E8E16B616A316,
	AndroidJNI_ToIntArray_mB69CEC2992884ADC394A9A7E604967B7B57651A9,
	AndroidJNI_ToLongArray_mFAAAB30B9A9944A7D6A590ADE0ACB50A11656928,
	AndroidJNI_ToFloatArray_m684CAD369A3BDCE75B31FCC68F8CF7A1293A4533,
	AndroidJNI_ToDoubleArray_mB04386ABEC07D54732102A858B7F5250B49601CE,
	AndroidJNI_ToObjectArray_m0614CB442A041E1EE108ADF05676C001710EC33A,
	AndroidJNI_FromBooleanArray_mA5AF86E8FDA0D4B7CCA395E708527E2A1073AA86,
	AndroidJNI_FromByteArray_mB1B0AC781BA50C8AE7F9A6B8660B7C3F6D7DDE02,
	AndroidJNI_FromSByteArray_m15A1A9366FC6A1952DA42809D8EEF59678ABF69E,
	AndroidJNI_FromCharArray_mB24FA47F69D0B382F0D3F5F4B62F9B6F14F52842,
	AndroidJNI_FromShortArray_m1084FF60F463C8EB3890406EEDBB9F1DFC80116B,
	AndroidJNI_FromIntArray_mD538A30307431BC4BEC75F3709701742131FE6F8,
	AndroidJNI_FromLongArray_m5EDB9FD73EBB1F49486524B6A62B644D171A3CA4,
	AndroidJNI_FromFloatArray_m5B41CA3BE4AAB40310042C0CFA624BFDBF1E15CB,
	AndroidJNI_FromDoubleArray_m0994CF71AF7314249C12F3070FC50E048446D63E,
	AndroidJNI_GetArrayLength_m3DD9BD96B89F86A4F8AAB10147CAADB951E49936,
	AndroidJNI_NewObjectArray_m49BBDBCC804A6799866B92D6E0DEA9A204B6BE43,
	AndroidJNI_GetObjectArrayElement_m104E43629B8731ACAF53A5D351CCB19398A75648,
	AndroidJNI_SetObjectArrayElement_m3CB77880BEEAA75E69813F5B193F07BDD8933418,
	AndroidJNISafe_CheckException_m39B8553ABAD4AFD5D34089327D3179870E168B9C,
	AndroidJNISafe_DeleteGlobalRef_mE0C851F30E3481496C72814973B66161C486D8BA,
	AndroidJNISafe_DeleteWeakGlobalRef_mB338C2F7116360905B7F444BDB16CAB18B914ED3,
	AndroidJNISafe_DeleteLocalRef_m9632EA13BF03AEE43FC7713125962A4D0DFFADC7,
	AndroidJNISafe_NewString_mD1D954E0EE5A8F135B19EE67E8FF2A4E1A6CA97F,
	AndroidJNISafe_GetStringChars_m15C4A04998812B41DF6E67D7D2F9F270573847FE,
	AndroidJNISafe_GetObjectClass_mB36866622A9FD487DCA6926F63038E5584B35BFB,
	AndroidJNISafe_GetStaticMethodID_m4DCBC629048509F8E8566998CDA8F1AB9EAD6A50,
	AndroidJNISafe_GetMethodID_m91CE11744503D04CD2AA8BAD99C914B1C2C6D494,
	AndroidJNISafe_FromReflectedMethod_m47AA20F4A2F8451B9BDCF8C6045802F04112F221,
	AndroidJNISafe_FindClass_mE58501828AA09ADC26347853AFE6D025845D487C,
	AndroidJNISafe_NewObject_m78BDA85E651167163148C9B39DEA8CE831EB1DB0,
	AndroidJNISafe_CallStaticVoidMethod_mC0BC9FA7E2FB69027E1F55E8810C6F619BCD7D59,
	AndroidJNISafe_CallStaticObjectMethod_m11EDE005224D5A6833BFF896906397D24E19D440,
	AndroidJNISafe_CallStaticStringMethod_mBB43D0D0B7D7ED48C90F9D9FF583A629DC40EBA3,
	AndroidJNISafe_CallStaticCharMethod_mC422B2FB9D7F13C0BEC8DAF00119B82FEA2854D9,
	AndroidJNISafe_CallStaticDoubleMethod_mC5A3C5AEEC15EB5D419E7B2B0A45DE2762310ABE,
	AndroidJNISafe_CallStaticFloatMethod_mA0AEAAA5ACCC7EB36F04616DCB2E09D29B6DED30,
	AndroidJNISafe_CallStaticLongMethod_mDEA9005EBB9126BD13C56C1D4497C60863F1D00B,
	AndroidJNISafe_CallStaticShortMethod_m970528ACEB23F9AE4A38A9B223B825DF10A64F09,
	AndroidJNISafe_CallStaticSByteMethod_m6F9A948F2EE6B668618D1B39FF3450368FA95010,
	AndroidJNISafe_CallStaticBooleanMethod_mD4AE550694EEC7859F137D0C60F0C94BD1092272,
	AndroidJNISafe_CallStaticIntMethod_mBBD8501C4128A05B243DEDD7FC1473B7F8B6DFCA,
	AndroidJNISafe_CallObjectMethod_m4E9B0BCDACAF851BA170F85BA9F06727B6A3452B,
	AndroidJNISafe_CallStringMethod_mF74DF782A0F41B0355910B4A6D1A88FFCA9E767D,
	AndroidJNISafe_CallCharMethod_mCE65F1C456B282169DFCD5A7D87E4DF78EE89626,
	AndroidJNISafe_CallDoubleMethod_m47F889A5E70637CDF523C7A84CC7F657FBEB8427,
	AndroidJNISafe_CallFloatMethod_m74F15E4AE8B0341919AD470E0528599F3042E0D5,
	AndroidJNISafe_CallLongMethod_m30E44F8538D228134490B925FF35A2E8D194D0FC,
	AndroidJNISafe_CallShortMethod_m0922D537A7A7C7576BA5CFA7359EEB1430B142B8,
	AndroidJNISafe_CallSByteMethod_mBC18848E620817FD4BCD72EB66E5EFDE64B34AA8,
	AndroidJNISafe_CallBooleanMethod_mE15E3147C3BD2BE20EE4ACD537DFB1253254E743,
	AndroidJNISafe_CallIntMethod_m014D37C85659EDCDDFF9A4007ED1943981525E95,
	AndroidJNISafe_FromCharArray_mDB6AE528FE52AC622EB833337F36AA93B5248E1B,
	AndroidJNISafe_FromDoubleArray_m10BE0E812ED3FC49D0FF7EFA7352F8EA026F824E,
	AndroidJNISafe_FromFloatArray_m087EAD07306786A03F15756F9EC26CA2AB6B8BCB,
	AndroidJNISafe_FromLongArray_mDCCAE11E1BB9C72B1DCB0D5CB4D191922EB499C5,
	AndroidJNISafe_FromShortArray_m05B4445B460FC16B41851A5C898123223C0B0024,
	AndroidJNISafe_FromByteArray_m8182D68596E21605519D27197C4870DCAB9F6550,
	AndroidJNISafe_FromSByteArray_m44649611607069754D9DD6A53B58C65AAE69C8E8,
	AndroidJNISafe_FromBooleanArray_m4CA0BE409AC39C391C4122A1DCE503B7EA87DC14,
	AndroidJNISafe_FromIntArray_m5AB9419F8E92A4815A833006025ABD0039D6B353,
	AndroidJNISafe_ToObjectArray_mB3A0EB74E8C47EB72667603D90A4DE2480E2AC63,
	AndroidJNISafe_ToCharArray_m8AB18ECC188D1B8A15966FF3FBD7887CF35A5711,
	AndroidJNISafe_ToDoubleArray_m9AE319DB92B91A255D2A0568D38B3B47CD0C69EB,
	AndroidJNISafe_ToFloatArray_m8ACA5E42C6F32E7D851613AC129FB37AFC28EBFD,
	AndroidJNISafe_ToLongArray_mD59D9304170DFB59B77342C994699BE445AF25D3,
	AndroidJNISafe_ToShortArray_m7D79F918714300B5818C7C8646E4E1A48E056A07,
	AndroidJNISafe_ToByteArray_m01C86D2FE9259F0888FA97B105FC741A0E2290D5,
	AndroidJNISafe_ToSByteArray_m5AE0F49EE17ABDCFBCDF619CBECD5DEF9961BDB8,
	AndroidJNISafe_ToBooleanArray_m1BCBD2041B6BFE6B91C1E3AD8C1133F791B70423,
	AndroidJNISafe_ToIntArray_m324EDE9CCF1C9909444C40617BD3358172EFB874,
	AndroidJNISafe_GetObjectArrayElement_mA87BFEFBCE1C7D1B5B817CCCB5D4B7F009FD37BD,
	AndroidJNISafe_GetArrayLength_m11614663772194842C0D75FB8C6FBDB92F8DEE05,
};
static const int32_t s_InvokerIndices[192] = 
{
	102,
	23,
	113,
	26,
	27,
	14,
	7,
	23,
	24,
	23,
	26,
	26,
	26,
	23,
	113,
	113,
	14,
	15,
	3,
	27,
	23,
	15,
	15,
	-1,
	-1,
	26,
	27,
	7,
	23,
	23,
	31,
	-1,
	-1,
	18,
	18,
	15,
	15,
	3,
	26,
	26,
	7,
	94,
	111,
	1813,
	1813,
	852,
	1814,
	1815,
	1816,
	3,
	852,
	24,
	1817,
	0,
	0,
	0,
	0,
	134,
	24,
	-1,
	852,
	-1,
	852,
	1814,
	1814,
	0,
	0,
	-1,
	852,
	1814,
	24,
	24,
	0,
	134,
	852,
	-1,
	-1,
	24,
	1818,
	722,
	3,
	1818,
	25,
	1818,
	25,
	1818,
	25,
	1819,
	1818,
	1820,
	1820,
	24,
	24,
	18,
	1821,
	1819,
	1822,
	1823,
	1824,
	1823,
	1824,
	1825,
	1826,
	1827,
	1821,
	1819,
	1822,
	1823,
	1824,
	1823,
	1824,
	1825,
	1826,
	1827,
	1828,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	1829,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	123,
	1830,
	1831,
	1832,
	3,
	25,
	25,
	25,
	24,
	18,
	1818,
	1820,
	1820,
	1818,
	24,
	1819,
	1828,
	1819,
	1821,
	1824,
	1826,
	1825,
	1827,
	1824,
	1823,
	1823,
	1822,
	1819,
	1821,
	1824,
	1826,
	1825,
	1827,
	1824,
	1823,
	1823,
	1822,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	18,
	1829,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	24,
	1831,
	123,
};
static const Il2CppTokenRangePair s_rgctxIndices[9] = 
{
	{ 0x06000018, { 0, 1 } },
	{ 0x06000019, { 1, 1 } },
	{ 0x06000020, { 2, 4 } },
	{ 0x06000021, { 6, 4 } },
	{ 0x0600003C, { 10, 2 } },
	{ 0x0600003E, { 12, 1 } },
	{ 0x06000044, { 13, 1 } },
	{ 0x0600004C, { 14, 1 } },
	{ 0x0600004D, { 15, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[16] = 
{
	{ (Il2CppRGCTXDataType)3, 21625 },
	{ (Il2CppRGCTXDataType)3, 21626 },
	{ (Il2CppRGCTXDataType)3, 21627 },
	{ (Il2CppRGCTXDataType)1, 24754 },
	{ (Il2CppRGCTXDataType)2, 24754 },
	{ (Il2CppRGCTXDataType)3, 21628 },
	{ (Il2CppRGCTXDataType)3, 21629 },
	{ (Il2CppRGCTXDataType)1, 24755 },
	{ (Il2CppRGCTXDataType)2, 24755 },
	{ (Il2CppRGCTXDataType)3, 21630 },
	{ (Il2CppRGCTXDataType)1, 24763 },
	{ (Il2CppRGCTXDataType)2, 24763 },
	{ (Il2CppRGCTXDataType)3, 21631 },
	{ (Il2CppRGCTXDataType)1, 30115 },
	{ (Il2CppRGCTXDataType)3, 21632 },
	{ (Il2CppRGCTXDataType)3, 21633 },
};
extern const Il2CppCodeGenModule g_UnityEngine_AndroidJNIModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_AndroidJNIModuleCodeGenModule = 
{
	"UnityEngine.AndroidJNIModule.dll",
	192,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	9,
	s_rgctxIndices,
	16,
	s_rgctxValues,
	NULL,
};
